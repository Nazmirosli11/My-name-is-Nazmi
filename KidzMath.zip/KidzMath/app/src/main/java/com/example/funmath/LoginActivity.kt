package com.example.kidzmath

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        val etName: EditText = findViewById(R.id.etName)
        val etAge: EditText = findViewById(R.id.etAge)
        val btnLogin: Button = findViewById(R.id.btnLogin)
        val btnBackToRegister: Button = findViewById(R.id.btnBackToRegister)

        btnLogin.setOnClickListener {
            val name = etName.text.toString().trim()
            val age = etAge.text.toString().trim()

            if (name.isEmpty() || age.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val storedAge = sharedPreferences.getString(name, null)

            if (storedAge != null && storedAge == age) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainMenuActivity::class.java)
                intent.putExtra("USER_NAME", name)
                intent.putExtra("USER_AGE", age)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "User not found! Please register first.", Toast.LENGTH_SHORT).show()
            }
        }

        btnBackToRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
