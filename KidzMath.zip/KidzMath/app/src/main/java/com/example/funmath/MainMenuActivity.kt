package com.example.kidzmath

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainMenuActivity : AppCompatActivity() {

    private var selectedCategory: String? = null // Stores selected category

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        val btnAddition = findViewById<Button>(R.id.btnAddition)
        val btnSubtraction = findViewById<Button>(R.id.btnSubtraction)
        val btnMultiplication = findViewById<Button>(R.id.btnMultiplication)
        val btnDivision = findViewById<Button>(R.id.btnDivision)
        val btnStartQuiz = findViewById<Button>(R.id.btnStartQuiz)

        // Category selection
        btnAddition.setOnClickListener { selectCategory("Addition") }
        btnSubtraction.setOnClickListener { selectCategory("Subtraction") }
        btnMultiplication.setOnClickListener { selectCategory("Multiplication") }
        btnDivision.setOnClickListener { selectCategory("Division") }

        // Start quiz button
        btnStartQuiz.setOnClickListener {
            if (selectedCategory != null) {
                val intent = Intent(this, QuizActivity::class.java)
                intent.putExtra("CATEGORY", selectedCategory) // Pass category to quiz
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please select a category first!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectCategory(category: String) {
        selectedCategory = category
        Toast.makeText(this, "$category selected", Toast.LENGTH_SHORT).show()
    }
}