package com.example.kidzmath

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private lateinit var tvQuestion: TextView
    private lateinit var btnOption1: Button
    private lateinit var btnOption2: Button
    private lateinit var btnOption3: Button
    private lateinit var btnOption4: Button
    private lateinit var btnNext: Button

    private var questionIndex = 0
    private var score = 0
    private var selectedCategory: String? = null

    private lateinit var questions: List<Question> // List of questions

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        tvQuestion = findViewById(R.id.tvQuestion)
        btnOption1 = findViewById(R.id.btnOption1)
        btnOption2 = findViewById(R.id.btnOption2)
        btnOption3 = findViewById(R.id.btnOption3)
        btnOption4 = findViewById(R.id.btnOption4)
        btnNext = findViewById(R.id.btnNext)

        selectedCategory = intent.getStringExtra("CATEGORY") // Get category from main menu
        questions = getQuestionsForCategory(selectedCategory) // Load questions based on category

        loadQuestion()

        // Answer selection
        btnOption1.setOnClickListener { checkAnswer(0) }
        btnOption2.setOnClickListener { checkAnswer(1) }
        btnOption3.setOnClickListener { checkAnswer(2) }
        btnOption4.setOnClickListener { checkAnswer(3) }

        btnNext.setOnClickListener {
            nextQuestion()
        }
    }

    private fun loadQuestion() {
        if (questionIndex < questions.size) {
            val currentQuestion = questions[questionIndex]
            tvQuestion.text = currentQuestion.question

            btnOption1.text = currentQuestion.options[0].toString()
            btnOption2.text = currentQuestion.options[1].toString()
            btnOption3.text = currentQuestion.options[2].toString()
            btnOption4.text = currentQuestion.options[3].toString()
        }
    }

    private fun checkAnswer(selectedIndex: Int) {
        val correctAnswerIndex = questions[questionIndex].correctAnswerIndex

        if (selectedIndex == correctAnswerIndex) {
            score++
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Wrong answer!", Toast.LENGTH_SHORT).show()
        }

        btnNext.isEnabled = true
    }

    private fun nextQuestion() {
        questionIndex++
        if (questionIndex < questions.size) {
            loadQuestion()
        } else {
            // Move to result screen
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("SCORE", score)
            startActivity(intent)
            finish()
        }
    }

    private fun getQuestionsForCategory(category: String?): List<Question> {
        return when (category) {
            "Addition" -> listOf(
                Question("What is 2 + 3?", listOf(5, 4, 6, 3), 0),
                Question("What is 4 + 1?", listOf(6, 5, 7, 3), 1),
                Question("What is 5 + 2?", listOf(8, 7, 9, 6), 1),
                Question("What is 6 + 1?", listOf(5, 8, 9, 7), 3),
                Question("What is 8 + 0?", listOf(8, 7, 6, 5), 0)
            )
            "Subtraction" -> listOf(
                Question("What is 5 - 3?", listOf(2, 3, 1, 4), 0),
                Question("What is 7 - 2?", listOf(5, 4, 6, 3), 2),
                Question("What is 9 - 4?", listOf(5, 6, 7, 4), 0),
                Question("What is 6 - 1?", listOf(4, 5, 3, 2), 1),
                Question("What is 8 - 0?", listOf(7, 8, 6, 5), 1)
            )
            "Multiplication" -> listOf(
                Question("What is 2 × 3?", listOf(5, 6, 7, 4), 1),
                Question("What is 4 × 2?", listOf(7, 8, 6, 9), 1),
                Question("What is 5 × 1?", listOf(4, 5, 6, 3), 1),
                Question("What is 6 × 1?", listOf(6, 7, 5, 8), 0),
                Question("What is 3 × 3?", listOf(8, 6, 9, 7), 2)
            )
            "Division" -> listOf(
                Question("What is 6 ÷ 2?", listOf(4, 3, 2, 5), 1),
                Question("What is 8 ÷ 4?", listOf(2, 3, 4, 1), 0),
                Question("What is 9 ÷ 3?", listOf(2, 3, 4, 5), 1),
                Question("What is 10 ÷ 5?", listOf(1, 2, 3, 4), 1),
                Question("What is 12 ÷ 4?", listOf(1, 2, 3, 4), 2)
            )
            else -> emptyList()
        }
    }
}

data class Question(
    val question: String,
    val options: List<Int>, // Numeric answers
    val correctAnswerIndex: Int
)
