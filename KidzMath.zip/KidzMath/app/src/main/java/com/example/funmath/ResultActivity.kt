package com.example.kidzmath

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val tvScore: TextView = findViewById(R.id.tvScore)
        val btnBackToMenu: Button = findViewById(R.id.btnBackToMenu)

        // Get score from intent
        val score = intent.getIntExtra("SCORE", 0)
        tvScore.text = "Your Score: $score / 5"

        // Go back to Main Menu
        btnBackToMenu.setOnClickListener {
            val intent = Intent(this, MainMenuActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP // Clears previous activities
            startActivity(intent)
            finish()
        }
    }
}
