package com.example.kidzmath

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class SplashActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val btnStart = findViewById<Button>(R.id.btnProceed)

        // If the user clicks the button, go to the main menu immediately
        btnStart.setOnClickListener {
            startMainMenu()
        }
    }

    private fun startMainMenu() {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
        finish() // Close splash screen so it doesn't come back when pressing back
    }
}